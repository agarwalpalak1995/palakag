//: Playground - noun: a place where people can play

import UIKit
protocol gymnastics
{
    func workoutSchedule(age:Int, weight:Int, height:Float, gender:String)
    func enrollment(numOfMonths: Int, fullname: String, idproof: String)
    func followDiet(typeofperson: String)
}
class fitness : gymnastics
  {
   var age:Int
   var weight:Int
   var height:Float
   var gender:String
   var fullname:String
   var idproof:String
    
  init(age: Int, weight: Int, height: Float, gender: String, fullname: String, idproof: String)
        
  {     self.age = age
        self.weight = weight
        self.height = height
        self.gender = gender
        self.fullname=fullname
        self.idproof=idproof
 }
    func workoutSchedule(age:Int, weight:Int, height:Float, gender:String)
        {
        if gender=="Male"
        {
        if age<40 && weight>75
        {
        print("abb workout 3 set of 15 wraps each")
        print("twister for 3 to 5 mins")
        }
else if age>40 && weight>75
        {
        print("abb workout 2 set of 10 wraps each")
        print("twister for 2 mins")
        }
      }
else
    {
     if age<40 && weight>60
            {
            print("twister for 2 to 4 mins")
            print("tredmill 12  mins minimum")
            }
        else if age>40 && weight>65
                {
                print("twister for 2 mins")
                print("tredmill for 8 to 10 mins")
                print("body charger for 5 mins")
            }}}
    func enrollment(numOfMonths: Int, fullname: String, idproof: String)
        {
    if numOfMonths==1
        {
        print("monthly basis and fees is Rs.1500")
        }
    else if numOfMonths==6
         {
         print("half yearly basis and fees is Rs.6600")
         }
    else if numOfMonths>6 && numOfMonths<=12
        {
        print("yearly basis and fees is Rs.\(numOfMonths*1000)")
        }
        }
    
    func followDiet(typeofperson: String)
        
    {
        if typeofperson == "gtomorph"
        { print("->MORNING: only warm or lemon water")
            
            print("->BREAKFAST one chapati or one prantha and one glass milk with no sugar")
        }
        else if typeofperson == "mesomorph"
        { print("->MORNING: only warm or lemon water")
            
            print("->BREAKFAST one chapati or one prantha and one glass milk with no sugar")
        }
        else if typeofperson == "andomorph"
        {
        print("->MORNING: only warm or lemon water")
        
        print("->BREAKFAST one chapati or one prantha and one glass milk with no sugar")
        
        print("->LUNCH 2 chapati only")
        
        print("->EVENING one glass of juice")
        
        }
    }
    }

class bodyBuilding : gymnastics
{
    var age:Int
    var weight:Int
    var height:Float
    var gender:String
    var fullname:String
    var idproof:String
    init(age: Int, weight: Int, height: Float, gender: String, fullname: String, idproof: String)
        
    {
        self.age = age
        self.weight = weight
        self.height = height
        self.gender = gender
        self.fullname=fullname
        self.idproof=idproof
    }
    func workoutSchedule(age:Int, weight:Int, height:Float, gender:String)
        {
        if gender=="Male"
            {
        if age<40 && weight>75
            {
            print("for bicep and triceps 3 set alternate days")
            print("for chest 3 set thrice in a week")
            }
        else if age>40 && weight>75
            {
                print("collar 2 sets once in a week")
                print("for v shape 3 sets once in a week")
            }
            }
        else
            
        {
             if age<40 && weight>60
                {
                print("for bicep and triceps 2 set alternate days")
                print("for chest 2 set twice in a week")
                print("shoulder 2 set twice in a week")
                }
            }
        }
    func enrollment(numOfMonths: Int, fullname: String, idproof: String)
        {
        if numOfMonths==1
        {
        print("->monthly basis and fees Rs.1500")
        }
        else if numOfMonths==3
        {
        print("->quaterly basis and fees Rs.4000")
        }
        else if numOfMonths==6
        {
        print("->half yearly basis and fees Rs.5000")
        }
        else if numOfMonths>6 && numOfMonths<=12
        {
        print("->yearly basis and fees is Rs.\(numOfMonths*2000)")
        }}
    func followDiet(typeofperson: String)
        {
        switch typeofperson
          {
        case "mesomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("evening schedule: 5pm to 9pm")
            
        case "gtomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("3pm to 4pm for extra workout")
            print("evening schedule: 5pm to 9pm")
            
        case "andomorph" :
            print("work out schedule for YOGA is as follow:")
            print("morning schedule: 5am to 10am")
            print(" please note : no evening schedule for yoga")
            
        default:
            print("invalid choice")
        }
    }
    
func limit(age:Int, weight:Int, height:Float, gender:String)
        
    { if gender=="Male"
        
    {
        if age<49 && weight>70 && height>170
        {
        print("max weight lifting 50")
        }
        else if(age>40 && weight>70 && height>170)
        {
        print("max weight limit is 40 kg")
        }
    }
else
    {
    if age<40 && weight>55 && height>155
    {
    print("max weight limit is 16 kg")
    }
    else if age>40 && weight>70 && height>155
    {
    print("max weight limit is 12 kg")
    }
   }
  }
}
class spatype : gymnastics
{   var age:Int
    var weight:Int
    var height:Float
    var gender:String
    var fullname:String
    var idproof:String
    init(age: Int, weight: Int, height: Float, gender: String, fullname: String, idproof: String)
    {
        self.age = age
        self.weight = weight
        self.height = height
        self.gender = gender
        self.fullname=fullname
        self.idproof=idproof
    }
    func workoutSchedule(age:Int, weight:Int, height:Float, gender:String)
        {
        if gender=="Male"
        {
        if age<40
                {
                 print("swim not for more than an hour")
                }
                else if age>40
                {
                print("swim not for more than an hour")
                }
        }
        else
        {if age<40
            {
           print("swim not for more than 1.5 hr")
            }
            else if age>40
            {
            print("swim not for more than an hour")
            }
            }}
    func enrollment(numOfMonths:Int, fullname:String, idproof:String)
        {
        if numOfMonths==1
            {
        print("monthly basis and fees is Rs.1000")
            
        }
            
        else if numOfMonths==3
            
        {
            
            print("quaterly basis and fees is Rs.2700")
            
        }
            
        else if numOfMonths==6
            
        {
            
            print("half yearly basis and fees is Rs.5000")
            
        }
            
        else if numOfMonths>6 && numOfMonths<=12
            
        {
            
            print("yearly basis and fees is Rs.\(numOfMonths*800)")
            
        }
        
    }
    
    func followDiet(typeofperson: String)
        
    {
        switch typeofperson
        {
        case "mesomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("evening schedule: 5pm to 9pm")
            
            
            
            
        case "gtomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("3pm to 4pm for extra workout")
            print("evening schedule: 5pm to 9pm")
            
            
            
            
            
        case "andomorph" :
            print("work out schedule for YOGA is as follow:")
            print("morning schedule: 5am to 10am")
            print(" please note : no evening schedule for yoga")
            
            
            
        default:
            print("invalid choice")
            

            
        }
        
}
    
}

class Yoga : gymnastics
    
{
    var age:Int
    var weight:Int
    var height:Float
    var gender:String
    var fullname:String
    var idproof:String
    init(age: Int, weight: Int, height: Float, gender: String, fullname: String, idproof: String)
        
    {
        
        self.age = age
        self.weight = weight
        self.height = height
        self.gender = gender
        self.fullname=fullname
        self.idproof=idproof
        
    }
    
    
    func workoutSchedule(age:Int, weight:Int, height:Float, gender:String)
        
    {
        
        print("nom vilom")
        print("kapal bhati")
        print("butterfly")
        
    }
    
    func enrollment(numOfMonths: Int, fullname: String, idproof: String)
        
    {
        
        if numOfMonths==1
            
        {
            print("monthly basis and fees is Rs.800")
        }
            
        else if numOfMonths==3
            
        {
            
            print("quaterly basis and fees is Rs.2100")
            
        }
            
        else if numOfMonths==6
            
        {
            
            print("half yearly basis and fees is Rs.3000")
            
        }
            
        else if numOfMonths>6 && numOfMonths<=12
            
        {
            
            print("yearly basis and fees is Rs.\(numOfMonths*650)")
            
        }
        
    }
    
    func followDiet(typeofperson: String)
        
    {
     
        
       
        switch typeofperson
        {
        case "mesomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("evening schedule: 5pm to 9pm")
            
          
            
            
        case "gtomorph" :
            print("work out schedule is as follow:")
            print("morning schedule: 5am to 12pm")
            print("3pm to 4pm for extra workout")
            print("evening schedule: 5pm to 9pm")
            
           
            
            
            
        case "andomorph" :
            print("work out schedule for YOGA is as follow:")
            print("morning schedule: 5am to 10am")
            print(" please note : no evening schedule for yoga")
            
           
            
        default:
            print("invalid choice")
        
    
      }
    
}

}

var palak=fitness(age:20, weight:50, height:160, gender:"female", fullname: "palak", idproof: "abc")

var mayank=bodyBuilding(age:19, weight:70, height:160, gender:"Male", fullname: "mayank", idproof: "def")

var aditi=spatype(age:21, weight:60, height:160, gender:"female", fullname: "aditi", idproof: "Uid")

var simar=bodyBuilding(age:21, weight:70, height:160, gender:"female", fullname: "simar", idproof: "Uid")

var anushree=Yoga(age:19, weight:70, height:160, gender:"female", fullname: "anushree", idproof: "Uid")

  print("************---------DIET PLAN--------***************")
 palak.followDiet(typeofperson: "andomorph")
 print("************---------DIET PLAN--------***************")
  aditi.followDiet(typeofperson: "gtomorph")
 print("************---------DIET PLAN--------***************")
mayank.followDiet(typeofperson: "mesomorph")



